g++ surfaceModeller.cpp -o a2 -I/opt/homebrew/include -L/opt/homebrew/lib -lGLEW -framework OpenGL -framework GLUT -std=c++17
./a2